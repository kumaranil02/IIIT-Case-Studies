# IIIT-Case-Studies

#case study 1: 
Referes to MovieAnalysis. This is typically a pandas data wrangling case study to find out the most rated movie,actor,director,highest gross profit etc. 
